import 'dart:convert';

LoginResponse loginResponseFromJson(String str) =>
    LoginResponse.fromJson(json.decode(str));

class LoginResponse {
  final User user;

  LoginResponse({
    required this.user,
  });

  factory LoginResponse.fromJson(Map<String, dynamic> json) {
    if (json["user"] == null) {
      return LoginResponse(
        user: User(
          name: Name(en: 'en', ar: 'ar'),
          avatar: Avatar(
            url:
                'https://icon-icons.com/icons2/3446/PNG/512/profile_user_avatar_people_icon_219228.png',
            publicId: 'publicId',
          ),
          dateOfBirth: DateTime.now(),
          id: 'id',
          facebookId: 'facebookId',
          slug: 'slug',
          email: 'email',
          phone: 0,
          phoneVerification: false,
          addresses: [],
          orders: [],
          role: 'role',
          isAdmin: false,
          favoriteRestaurants: [],
          favoriteMeals: [],
          createdAt: DateTime.now(),
          updatedAt: DateTime.now(),
          v: 0,
          accessToken: 'accessToken',
          refreshToken: 'refreshToken',
          gender: 'gender',
          logout: DateTime.now(),
          passwordOtpExpire: DateTime.now(),
          userId: 'userId',
        ),
      );
    }

    return LoginResponse(
      user: User.fromJson(json["user"]),
    );
  }
}

class User {
  final Name name;
  final Avatar avatar;
  final DateTime dateOfBirth;
  final String id;
  final String facebookId;
  final String slug;
  final String email;
  final int phone;
  final bool phoneVerification;
  final List<dynamic> addresses;
  final List<dynamic> orders;
  final String role;
  final bool isAdmin;
  final List<FavoriteRestaurants> favoriteRestaurants;
  final List<FavoriteMeals> favoriteMeals;
  final DateTime createdAt;
  final DateTime updatedAt;
  final int v;
  final String accessToken;
  final String refreshToken;
  final String gender;
  final DateTime logout;
  final DateTime passwordOtpExpire;
  final String userId;

  User({
    required this.name,
    required this.avatar,
    required this.dateOfBirth,
    required this.id,
    required this.facebookId,
    required this.slug,
    required this.email,
    required this.phone,
    required this.phoneVerification,
    required this.addresses,
    required this.orders,
    required this.role,
    required this.isAdmin,
    required this.favoriteRestaurants,
    required this.favoriteMeals,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.accessToken,
    required this.refreshToken,
    required this.gender,
    required this.logout,
    required this.passwordOtpExpire,
    required this.userId,
  });

  factory User.fromJson(Map<String, dynamic> json) => User(
        name: Name.fromJson(json["name"]),
        avatar: Avatar.fromJson(json["avatar"]),
        dateOfBirth: DateTime.parse(
          json["dateOfBirth"] ?? DateTime.now().toString(),
        ),
        id: json["_id"],
        facebookId: json["facebookId"],
        slug: json["slug"],
        email: json["email"],
        phone: json["phone"],
        phoneVerification: json["phoneVerification"],
        addresses: List<dynamic>.from(json["addresses"].map((x) => x)),
        orders: List<dynamic>.from(json["orders"].map((x) => x)),
        role: json["role"],
        isAdmin: json["isAdmin"],
        favoriteRestaurants: List<FavoriteRestaurants>.from(
            json["favoriteRestaurants"]
                .map((x) => FavoriteRestaurants.fromJson(x))),
        favoriteMeals: List<FavoriteMeals>.from(
            json["favoriteMeals"].map((x) => FavoriteMeals.fromJson(x))),
        createdAt: DateTime.parse(json["createdAt"]),
        updatedAt: DateTime.parse(json["updatedAt"]),
        v: json["__v"],
        accessToken: json["accessToken"],
        refreshToken: json["refreshToken"],
        gender: json["gender"],
        logout: DateTime.parse(json["logout"]),
        passwordOtpExpire: DateTime.parse(json["passwordOtpExpire"]),
        userId: json["id"],
      );
}

class Avatar {
  final String url;
  final String publicId;

  Avatar({
    required this.url,
    required this.publicId,
  });

  factory Avatar.fromJson(Map<String, dynamic> json) => Avatar(
        url: json["url"],
        publicId: json["publicId"] ?? '',
      );

  Map<String, dynamic> toJson() => {
        "url": url,
        "publicId": publicId,
      };
}

class FavoriteRestaurants {
  final bool isAdded;
  final String id;
  final String restaurant;

  FavoriteRestaurants({
    required this.isAdded,
    required this.id,
    required this.restaurant,
  });

  factory FavoriteRestaurants.fromJson(Map<String, dynamic> json) =>
      FavoriteRestaurants(
        isAdded: json["isAdded"],
        id: json["_id"],
        restaurant: json["restaurant"],
      );

  Map<String, dynamic> toJson() => {
        "isAdded": isAdded,
        "_id": id,
        "restaurant": restaurant,
      };
}

class FavoriteMeals {
  final bool isAdded;
  final String id;
  final String meals;

  FavoriteMeals({
    required this.isAdded,
    required this.id,
    required this.meals,
  });

  factory FavoriteMeals.fromJson(Map<String, dynamic> json) => FavoriteMeals(
        isAdded: json["isAdded"],
        id: json["_id"],
        meals: json["meals"],
      );

  Map<String, dynamic> toJson() => {
        "isAdded": isAdded,
        "_id": id,
        "meals": meals,
      };
}

class Name {
  final String en;
  final String ar;

  Name({
    required this.en,
    required this.ar,
  });

  factory Name.fromJson(Map<String, dynamic> json) => Name(
        en: json["en"],
        ar: json["ar"],
      );

  Map<String, dynamic> toJson() => {
        "en": en,
        "ar": ar,
      };
}
