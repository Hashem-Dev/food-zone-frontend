import 'package:food_zone/exports.dart';
import 'package:food_zone/features/auth/email/data/repositories/verify_otp.dart';
import 'package:food_zone/features/auth/email/presentation/pages/email_otp.dart';
import 'package:food_zone/features/auth/login/data/models/login_request.dart';
import 'package:food_zone/features/auth/login/data/models/login_response.dart';
import 'package:food_zone/features/auth/login/presentation/manager/controllers/password.dart';
import 'package:food_zone/features/main/presentation/pages/main_screen.dart';
import 'package:food_zone/features/splash/data/repositories/load_user_data.dart';

import 'package:http/http.dart' as http;

class LoginController extends GetxController {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final FocusNode emailFocus = FocusNode();
  final FocusNode passwordFocus = FocusNode();
  final RxBool emailRequired = false.obs;
  final RxBool passwordRequired = false.obs;
  final RxBool fillEmail = true.obs;
  final LoginPasswordController password = Get.put(LoginPasswordController());
  final dataController = Get.put(LoadUserDataController());
  final RxBool _isLoading = false.obs;

  void login(BuildContext context) async {
    final bool isValidEmail = validateEmail(context);
    if (!isValidEmail) {
      return;
    }

    final bool isValidPassword = validatePassword(context);
    if (!isValidPassword) {
      return;
    }

    setLoading(true);
    final email = emailController.text;
    final password = passwordController.text;

    final LoginRequest data = LoginRequest(email: email, password: password);
    final body = loginRequestToJson(data);

    final url = Uri.parse('$baseUrl/users/');
    try {
      final request = http.Request('GET', url);
      request.body = body;
      request.headers.addAll(headers);
      final response = await request.send();
      final encodedUserData = await response.stream.bytesToString();
      final decodedResponse = jsonDecode(encodedUserData);

      if (response.statusCode == 200) {
        final userData = loginResponseFromJson(encodedUserData);
        await prefs.saveUserEmail(userData.user.email);
        await prefs.saveAccessToken(userData.user.accessToken);
        await prefs.saveRefreshToken(userData.user.refreshToken);
        await prefs.saveUserDate(encodedUserData);
        await prefs.reFreshPreferences();
        await dataController.loadFavoriteRestaurant();
        await dataController.loadFavoriteMeals();
        if (context.mounted) {
          showSuccessSnackBar(context.translate.welcome_back);
        }
        setLoading(false);
        Get.deleteAll(force: true);
        Get.delete<LoginPasswordController>(force: true);
        Get.delete<LoginController>(force: true);

        Get.offAll(() => const MainScreen());
      } else if (response.statusCode == 409) {
        final verifyTypeController = Get.put(
          VerifyOtpController(),
          permanent: true,
        );
        showErrorSnackBar(decodedResponse['message']);
        Get.to(() => const EmailVerificationCode());
        verifyTypeController.verificationType.value = 'register';
        verifyTypeController.email.value = emailController.text;
        setLoading(false);
      } else {
        showErrorSnackBar(decodedResponse['message']);
        setLoading(false);
      }
    } catch (error) {
      setLoading(false);
      rethrow;
    }
  }

  bool validateEmail(BuildContext context) {
    final email = emailController.text;
    final RegExp emailRegex = RegExp(
      r'^[a-zA-Z0-9._%+-]+@(gmail|yahoo|outlook)\.com$',
    );

    final bool emailMatch = emailRegex.hasMatch(email);
    if (email.isEmpty) {
      showErrorSnackBar(context.translate.email_required);
      emailRequired.value = true;
      emailFocus.requestFocus();
      return false;
    } else if (!emailMatch) {
      showErrorSnackBar(context.translate.email_accepted);
      emailFocus.requestFocus();
      return false;
    }
    return true;
  }

  bool validatePassword(BuildContext context) {
    final String userPassword = passwordController.text;
    final bool isValidate = password.validationResult.contains(false);

    if (userPassword.isEmpty) {
      showErrorSnackBar(context.translate.password_required);
      passwordRequired.value = true;
      passwordFocus.requestFocus();
      return false;
    }

    if (isValidate) {
      showErrorSnackBar(context.translate.password_not_follow_rules);
      passwordRequired.value = true;
      passwordFocus.requestFocus();
      return false;
    }

    return true;
  }

  void setEmail() {
    final String userEmail = prefs.userEmail;
    if (fillEmail.value) {
      if (userEmail.isNotEmpty) {
        emailController.text = userEmail;
      }
    }
    fillEmail.value = false;
  }

  void setLoading(bool loading) {
    _isLoading.value = loading;
  }

  bool get loading => _isLoading.value;

  @override
  void onClose() {
    emailController.dispose();
    passwordController.dispose();
    super.onClose();
  }
}
